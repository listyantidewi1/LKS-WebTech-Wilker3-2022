#WP Turbolinks 5
A small Plugin to activate Turbolinks in your WordPress Frontend.

You can find a [Demo](https://medienproduzent.net) on my Blog. Just navigate around.

You can find more about Turbolinks [here](https://github.com/turbolinks/turbolinks).


Features
--
⚡️ Lightning Fast Frontend


Known Issues
--
- 🐞The WP Adminbar ist not compatible yet. Turbolinks only gets activated when you are **not** logged in. So to speak, if you are a normal visitor.


