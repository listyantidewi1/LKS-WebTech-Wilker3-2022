/**
 * Internal dependencies
 */
import './shared/public-path';
