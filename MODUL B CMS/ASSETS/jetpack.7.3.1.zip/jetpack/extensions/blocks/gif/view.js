/**
 * Internal dependencies
 */
import './style.scss';
