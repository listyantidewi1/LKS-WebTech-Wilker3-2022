export default function Column( { children } ) {
	return <div className="tiled-gallery__col">{ children }</div>;
}
