
//	CUSTOM JS FOR wpdevart OPTIONS
/**
 * Custom scripts needed for the colorpicker, image button selectors,
 * and navigation tabs.
 */

jQuery(document).ready(function($) {
	
	// Loads the color pickers
	$('.of-color').wpColorPicker();

});