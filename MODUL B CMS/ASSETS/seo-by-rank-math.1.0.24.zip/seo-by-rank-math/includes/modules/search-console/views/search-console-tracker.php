<?php
/**
 * Search console tracker screen.
 *
 * @package Rank_Math
 */

?>
<div class="search-console-analysis-tracker">

	<div class="search-console-analysis-tracker-list" style="width: 98%;box-sizing: border-box;">
		<h1 style="text-align:center;font-size:3em;padding: 20px;"><?php esc_html_e( 'Coming Soon', 'rank-math' ); ?></h1>
	</div>

</div>
