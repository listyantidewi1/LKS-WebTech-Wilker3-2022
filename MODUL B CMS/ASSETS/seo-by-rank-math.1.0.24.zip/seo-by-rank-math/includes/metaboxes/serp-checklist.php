<?php
/**
 * Display SERP checklist
 *
 * @package    RankMath
 * @subpackage RankMath\Metaboxes
 */

use RankMath\Admin\Serp_Checklist;

$checklist = new Serp_Checklist;
$checklist->display();
