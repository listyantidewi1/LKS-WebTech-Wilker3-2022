<?php
/**
 * As for me, I consider myself as a speck of the dust of the devotee's feet.
 *
 * - Sri Ramakrishna Paramahansa
 */
