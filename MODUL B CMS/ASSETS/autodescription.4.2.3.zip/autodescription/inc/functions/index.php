<?php
/**
 * The highest proof of virtue is to possess boundless power without abusing it.
 *
 * - Thomas Babington Macaulay, 1st Baron Macaulay
 */
