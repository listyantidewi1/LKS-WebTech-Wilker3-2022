<?php
/**
 * They say that God is everywhere,
 * and yet we always think of Him as somewhat of a recluse.
 *
 * - Emily Dickinson
 */
