<?php
/**
 * Tell me and I forget. Teach me and I remember. Involve me and I learn.
 *
 * - Benjamin Franklin
 */
