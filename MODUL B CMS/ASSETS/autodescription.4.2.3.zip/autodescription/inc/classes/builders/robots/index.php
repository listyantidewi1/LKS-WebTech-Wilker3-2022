<?php
/**
 * People aren't that worried about what you're doing or what you're saying,
 * so you can drift around the world relatively anonymously.
 * You must not feel persecuted and examined.
 * Liberate yourself from that idea that people are watching you.
 *
 * - Russell Brand
 */
