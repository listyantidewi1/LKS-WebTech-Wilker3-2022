<?php
/**
 * On ne définit que par désespoir. Il faut une formule ; il en faut même beaucoup,
 * ne serait-ce que pour donner une justification à l'espirit et une façade au néant.
 * Le concept ni l'extase ne sont opérants. Quant la musique nous plonge jusqu'aux
 * « intimités » de l'être, nous remontos rapidement à la surface : les effets
 * de l'illusion se dissipent et le savoir s'avère nul.
 *
 * - Emil Cioran
 *
 * Translated (by Sybre):
 * We only define out of desperation. We need a formula; it even takes a lot,
 * if only giving a justification to the spirit and a facade to nothingness.
 * The concept nor the ecstasy are operative. When the music plunges us to
 * the "intimacies" of being, we quickly come to the surface: the effects
 * of the illusion dissipate and knowledge turns out void.
 */
