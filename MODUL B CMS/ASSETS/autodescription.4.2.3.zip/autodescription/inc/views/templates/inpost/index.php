<?php
/**
 * Painting is easy when you don't know how, but very difficult when you do.
 *
 * - Edgar Degas
 */
