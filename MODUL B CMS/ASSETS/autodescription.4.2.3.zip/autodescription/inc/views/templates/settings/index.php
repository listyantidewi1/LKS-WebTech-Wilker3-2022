<?php
/**
 * The best way to find yourself is to lose yourself in the service of others.
 *
 * - Mahātmā Mohandas Karamchand Gandhi
 */
