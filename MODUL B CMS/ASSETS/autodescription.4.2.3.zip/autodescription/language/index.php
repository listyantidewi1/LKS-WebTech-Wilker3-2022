<?php
/**
 * To be trusted is a greater compliment than being loved.
 *
 * - George MacDonald
 */
