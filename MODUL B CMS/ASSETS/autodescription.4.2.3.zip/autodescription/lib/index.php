<?php
/**
 * Un jardín debe combinar lo poético y lo misterioso con una sensación de serenidad y alegría.
 *
 * (A garden must combine the poetic and the mysterious with a feeling of serenity and joy.)
 *
 * - Luis Barragan
 */
